#ifndef UTILS_H
#define UTILS_H

int random_getal_tussen(int min, int max);

#endif